package com.college.departmentcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentcrudApplication.class, args);
	}

}
